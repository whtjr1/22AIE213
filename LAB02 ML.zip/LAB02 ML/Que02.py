import numpy as np
from collections import Counter

def euclidean_dist(v1, v2):
    return np.sqrt(np.sum((v1 - v2)**2))

def kNN(X_train, Y_train, X_test, k):
    predictions = []
   
    for test_case in X_test:
        distances = [euclidean_dist(test_case, train_case) for train_case in X_train]
        sorted_index = np.argsort(distances)
        nearest_labels = Y_train[sorted_index[:k]]
       
        # Use Counter to find the most common label among k neighbors
        most_common_label = Counter(nearest_labels).most_common(1)[0][0]
        predictions.append(most_common_label)
   
    return np.array(predictions)

if __name__ == "__main__":
   
    value_of_k = 2

    X_train = np.array([[1, 2], [2, 3], [3, 4], [4, 5]])
    Y_train = np.array([0, 0, 1, 1])

    X_test = np.array([[2, 3], [4, 5]])

    predictions = kNN(X_train, Y_train, X_test,value_of_k)
    print(f"Predicted Neighbor Labels: {predictions}")
