import numpy as np
def label_encoding(data):
    unique_components = list(set(data))
    component_to_label_mapping = {category: label for label, category in enumerate(unique_components)}
    encoded_data = np.array([component_to_label_mapping[category] for category in data])

    return encoded_data, component_to_label_mapping


if __name__ == "__main__":
    categ_data = ["red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green",
                  "red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green",
                  "red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green",
                  "red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green"]

    encoded_data, mapping = label_encoding(categ_data)

    print(f"Categorical Data: {categ_data}")
    print(f"Encoded Data: {encoded_data}")
    print(f"Label Mapping: {mapping}")

