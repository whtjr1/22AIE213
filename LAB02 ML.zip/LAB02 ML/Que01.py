import math

def euclidean_dist(v1,v2):
    if len(v1) != len(v2):
        raise ValueError("Both the vectors should have the same dimensionality")
   
    squared_dist = [(a - b)**2 for a, b in zip(v1, v2)]
    sum_of_squares_of_distances = sum(squared_dist)
    dist = math.sqrt(sum_of_squares_of_distances)
    return dist


def manhattan_dist(v1,v2):
   
    if len(v1) != len(v2):
        raise ValueError("Both the vectors should have the same dimensionality")
   
    distances = [abs(a - b) for a, b in zip(v1, v2)]
    dist = sum(distances)
    return dist


if __name__ == "__main__":
    vector_a = [1, 2, 3]
    vector_b = [4, 5, 6]

    euclidean = euclidean_dist(vector_a, vector_b)
    print(f"Euclidean Distance between 2 vectors: {euclidean}")

    manhattan = manhattan_dist(vector_a, vector_b)
    print(f"Manhattan Distance between 2 vectors: {manhattan}")
