import numpy as np

def one_hot_encoding(data):
   
    unique_components = list(set(data))
    component_to_index_mapping = {category: index for index, category in enumerate(unique_components)}
   
    # Initialize an array of zeros for one-hot encoding
    one_hot_encode = np.zeros((len(data), len(unique_components)))

    for row_index, category in enumerate(data):
        col_index =  component_to_index_mapping[category]
        one_hot_encode[row_index, col_index] = 1

    return one_hot_encode, unique_components

# Example usage in the main program:
if __name__ == "__main__":
    # Example categorical data
    categorical_data = ["red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green",
                  "red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green",
                  "red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green",
                  "red", "green", "blue", "red", "green","red", "green", "blue", "red", "green" ,"red", "green", "blue", "red", "green"]    # Use one-hot encoding function
    one_hot_encoded_data, categories = one_hot_encoding(categorical_data)

    # Print the results
    print(f"Categorical Data: {categorical_data}")
    print(f"One-Hot Encoded Data:\n{one_hot_encoded_data}")
    print(f"Categories: {categories}")
