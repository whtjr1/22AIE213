import numpy as np
import pandas as pd

# Loading the data from the given Excel file
path_of_the_file = "Lab Session1 Data.xlsx"
df = pd.read_excel(path_of_the_file, sheet_name="Purchase data") 

k = 5  # Based on the input features change this value

# Converting each column to numeric, handling errors by replacing non-numeric values with NaN
A = df.iloc[:, :k].apply(pd.to_numeric, errors='coerce')

# Filling NaN values with another specific value, e.g., 0
A.fillna(0, inplace=True)

C = df.iloc[:, k:]  # Adjust the value of 'k' accordingly

# Calculating the dimensionality of the vec space
dim = A.shape[1]

# Calculating the number of vectors in the vec space
num_of_vectors = A.shape[0]

# Calculating the rank of Matrix " A "
rank_of_A = np.linalg.matrix_rank(A)

# Calculate the pseudo-inverse of Matrix " A "
A_pseudo_inv = np.linalg.pinv(A)

# Calculating the cost of each product using the pseudo-inverse of the matrix
cost_per_product = np.dot(A_pseudo_inv, C)

# Printing the results
print(f"Dimensionality of the vec space: {dim}")
print(f"Number of vectors in the vec space: {num_of_vectors}")
print(f"Rank of Matrix A: {rank_of_A}")
print(f"Cost per each product:\n{cost_per_product}")
