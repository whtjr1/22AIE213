import numpy as np
import pandas as pd

# Loading the data from the given Excel file
path_of_the_file = "Lab Session1 Data.xlsx"
df = pd.read_excel(path_of_the_file, sheet_name="Purchase data")  

k = 5 # Based on the input features change this value

# Converting each column to numeric, handling errors by replacing non-numeric values with NaN
A = df.iloc[:, :k].apply(pd.to_numeric, errors='coerce')

# Filling NaN values with another specific value, e.g., 0
A.fillna(0, inplace=True)

C = df.iloc[:, k:]  # Adjust the value of 'k' accordingly

# Calculating the pseudo-inverse of Matrix "A"
pseudo_inv_of_A = np.linalg.pinv(A)

# Calculating the model vector "X", which is a dot product of pseudo inverse and "C"
X = np.dot(pseudo_inv_of_A, C)

# Printing the model vector "X"
print(f"Model vector X:\n{X}")
