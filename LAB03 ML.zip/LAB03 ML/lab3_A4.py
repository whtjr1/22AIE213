import pandas as pd
import numpy as np
import statistics
import matplotlib.pyplot as plt

# Loading the data from the given Excel file
path_of_the_file = "Lab Session1 Data.xlsx"
df_irctc = pd.read_excel(path_of_the_file, sheet_name="IRCTC Stock Price")

# Step 1: Calculating the mean and variance of the "Price data"
price_data = df_irctc['Price']
price_mean = statistics.mean(price_data)
price_variance = statistics.variance(price_data)

print(f"Mean of the Price data: {price_mean}")
print(f"Variance of the Price data: {price_variance}")

# Step 2: Selecting the price data for all Wednesdays and also calculating the sample mean
wednesday_data = df_irctc[df_irctc['Day'] == 'Wednesday']['Price']

if not wednesday_data.empty:
    sample_mean_of_wednesday = statistics.mean(wednesday_data)
    print(f"Sample mean of the Wednesday price data: {sample_mean_of_wednesday}")
else:
    print("No data is available for Wednesdays")

# Step 3: Selecting the price data for the month of April and calculating the sample mean
april_data = df_irctc[df_irctc['Month'] == 'Apr']['Price']
sample_mean_of_april = statistics.mean(april_data)

print(f"Sample mean of the April price data: {sample_mean_of_april}")

# Step 4: Finding the probability of making a loss over the stock
loss_of_probability = np.mean(df_irctc['Chg%'].apply(lambda x: x < 0))
print(f"Probability of making a loss over the stock: {loss_of_probability}")

# Step 5: Calculating the probability of making a profit on Wednesday of the month
wednesday_profit_making_probability = np.mean((df_irctc['Day'] == 'Wednesday') & (df_irctc['Chg%'] > 0))
print(f"Probability of making a profit on Wednesday of the month: {wednesday_profit_making_probability}")

# Step 6: Calculating the conditional probability of making profit, given that today it is Wednesday
if not wednesday_data.empty:
    conditional_profit_making_probability = wednesday_data[wednesday_data > 0].count() / wednesday_data.count()
    print(f"Conditional probability of making profit on Wednesday: {conditional_profit_making_probability}")
else:
    print("No profit making data available for Wednesdays")


# Step 7: Scatter ploting of Chg% data against the day of the week
plt.scatter(df_irctc['Day'], df_irctc['Chg%'])
plt.xlabel('Day of the Week')
plt.ylabel('Chg%')
plt.title('Scatter Plot of Chg% Data Against Day of the Week')
plt.show()
