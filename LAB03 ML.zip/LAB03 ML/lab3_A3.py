import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Loading the data from the given Excel file
path_of_the_file = "Lab Session1 Data.xlsx"
df = pd.read_excel(path_of_the_file, sheet_name="Purchase data") 

k = 5  # Based on the input features change this value

# Converting each column to numeric, handling errors by replacing non-numeric values with NaN
A = df.iloc[:, :k].apply(pd.to_numeric, errors='coerce')

# Filling NaN values with another specific value, e.g., 0
A.fillna(0, inplace=True)

payments_column_name = 'Payment (Rs)'
payments = df[payments_column_name]

# Create the target variable labling(class labels: RICH or POOR)
target = np.where(payments > 200, 'RICH', 'POOR')

# Spliting the data into training and testing data
X_train, X_test, y_train, y_test = train_test_split(A, target, test_size=0.2, random_state=42)

# Creating a Random Forest classifier
classifier = RandomForestClassifier(random_state=42)

# Training the classifier with the training data
classifier.fit(X_train, y_train)

# Making predictions on the testing data
predictions = classifier.predict(X_test)

# Evaluate the classifier
accuracy = accuracy_score(y_test, predictions)
result_of_classification_report = classification_report(y_test, predictions, zero_division=1)

print(f"Accuracy: {accuracy}")
print("Classification Report:\n", result_of_classification_report)
